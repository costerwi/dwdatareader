#include "DWLoadLib.h"
#include <stdio.h>

int main(int argc, char *argv[])
{
	int i, k, n;
	struct DWFileInfo fi;
	__int64 sample_cnt;
	double* data;
	double* time_stamp;
	int ch_list_cnt;
	struct DWChannel* ch_list;
	int event_list_cnt;
	struct DWEvent* event_list;
	char str[256];
	double ch_scale, ch_offset;

	if (!LoadDWDLL())// Load DLL
	{
		printf("Could not load dll object\n");
		return 0;
	};

	DWInit();//initiate dll
	printf("DW Version = %i\n", DWGetVersion());//Get dll version

	if ( (argc > 1) && (!DWOpenDataFile(argv[1], &fi)) )//open dewesoft file
	{
		//Get File Information
		printf("FILE INF: sample rate = %fHz, start store time = %fdays, duration = %fsec \n", fi.sample_rate, fi.start_store_time, fi.duration);

		//storing type
		printf("Storing type=%d \n", DWGetStoringType());

		//Get Data Header
		printf("\nDATA HEADER:\n");
		ch_list_cnt = DWGetHeaderEntryCount();//get channels count
		ch_list = (struct DWChannel*)malloc(sizeof(struct DWChannel) * ch_list_cnt);
		DWGetHeaderEntryList(ch_list);// get all channels
		for(i = 0; i < ch_list_cnt; i++)
		{
			DWGetHeaderEntryText(ch_list[i].index, str, 255);
			printf("Name=%s Unit=%s value=%s\n", ch_list[i].name, ch_list[i].unit, str);
		}
		free(ch_list);

		//Get all events (start trigger, stop trigger, ...)
		printf("\nEVENTS:\n");
		event_list_cnt = DWGetEventListCount();//get event list count
		event_list = (struct DWEvent*)malloc(sizeof(struct DWEvent) * event_list_cnt);
		DWGetEventList(event_list);
		for(i = 0; i < event_list_cnt; i++)
			printf("EVENT: type = %i, text = %s, position = %fsec \n", event_list[i].event_type, event_list[i].event_text, event_list[i].time_stamp);
		free(event_list);

		//Get all channels
    	ch_list_cnt = DWGetChannelListCount();//get channels count
		ch_list = malloc(sizeof(struct DWChannel) * ch_list_cnt);
		DWGetChannelList(ch_list);// get all channels
		printf("\nCHANNELS:\n");
		for(i = 0; i < ch_list_cnt; i++)
		{
			DWGetChannelFactors(ch_list[i].index, &ch_scale, &ch_offset);
			printf("Index=%i Name=%s Unit=%s Description=%s Scale=%f Offset=%f\n", ch_list[i].index, ch_list[i].name, ch_list[i].unit, ch_list[i].description, ch_scale, ch_offset);
		}

		//Get data from all channels
		printf("\nDATA:\n");
		for(i = 0; i < ch_list_cnt; i++)
		{
			printf("Channel=%s ", ch_list[i].name);
			sample_cnt = DWGetScaledSamplesCount(ch_list[i].index);//get channel sample count
			data = malloc(sizeof(double) * sample_cnt * ch_list[i].array_size);
			time_stamp = malloc(sizeof(double) * sample_cnt);
			DWGetScaledSamples(ch_list[i].index, 0, sample_cnt, data, time_stamp);//Get channel data
/*
			if(i == 0)
			{//write channel data in text file
				FILE *file_p;
				char* FileName = "c:\\example.txt";
				file_p = fopen(FileName,"w");
				for(k = 0; k < sample_cnt; k++)
					for (n = 0; n < ch_list[i].array_size; n ++)
						fprintf(file_p, "%f\t%f\n", data[k * ch_list[i].array_size + n], time_stamp[k]);
				fclose(file_p);
			}
			*/
			free(data);
			free(time_stamp);
			printf("\n");
		}
		free(ch_list);

		DWCloseDataFile();//close dewesoft data file
	}

	DWDeInit();// clear dll

	CloseDWDLL();

	printf("\n\n\n");

	return 0;
}
