#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>

#ifndef DWLOADLIB__H
#define DWLOADLIB__H

#define __int64 int64_t

enum DWStatus					//status returned from library function calls
{
	DWSTAT_OK = 0,							//status is OK
	DWSTAT_ERROR = 1, 						//error occurred in the dll
	DWSTAT_ERROR_FILE_CANNOT_OPEN = 2,		//cannot open d7d file
	DWSTAT_ERROR_FILE_ALREADY_IN_USE = 3,	//file already in use
	DWSTAT_ERROR_FILE_CORRUPT = 4, 			//d7d file was corrupted
	DWSTAT_ERROR_NO_MEMORY_ALLOC = 5		// memory must be allocated
};

#pragma pack(push)
#pragma pack(1)
struct DWFileInfo				//structure used for data file
{ 
	double sample_rate;			//the sampling rate
	double start_store_time;	//absolute time of the start of storing (days)
	double duration;			//duration of data file (seconds)
};

#pragma pack(1)
struct DWChannel				//structure used for DeweSoft channel
{
	int index;					//unique channel identifier
	char name[100];				//the name of a channel
	char unit[20];				//the unit of a channel
	char description[200];		//the description of a channel
	unsigned int color;			//specifies the color of a channel
	int array_size;				//length of the array channel (normal array_size = 1)
};

#pragma pack(1)
struct DWEvent
{
	int event_type;				//1..start event; 2..stop event
	double time_stamp;			//relative position in seconds
	char event_text[200];
};

#pragma pack(1)
struct DWReducedValue
{
    double time_stamp;			//relative time in seconds
    double ave;
    double min;
	double max;
	double rms;
};

#pragma pack(1)
struct DWArrayInfo
{
	int index;				//unique axis identifier
	char name[100];			//axis name
	char unit[20];			//axis unit
	int size;				//length of the axis size
};
#pragma pack(pop)

//event list
#define etStart 1
#define etStop 2
#define etTrigger 3
#define etVStart 11
#define etVStop 12
#define etKeyboard 20
#define etNotice 21
#define etVoice 22
#define etModule 24

//Storing type
#define ST_ALWAYS_FAST 0
#define ST_ALWAYS_SLOW 1
#define ST_FAST_ON_TRIGGER 2
#define ST_FAST_ON_TRIGGER_SLOW_OTH 3


//FUNCTIONS:
typedef enum DWStatus (*_DWInit)(void);
typedef enum DWStatus (*_DWDeInit)(void);
typedef int (*_DWGetVersion)(void);
typedef enum DWStatus (*_DWOpenDataFile)(char* file_name, struct DWFileInfo* file_info);
typedef enum DWStatus (*_DWCloseDataFile)(void);
typedef int (*_DWGetChannelListCount)(void);
typedef enum DWStatus (*_DWGetChannelFactors)(int ch_index, double* scale, double* offset);
typedef enum DWStatus (*_DWGetChannelList)(struct DWChannel* channel_list);
typedef __int64 (*_DWGetScaledSamplesCount)(int ch_index);
typedef  enum DWStatus (*_DWGetScaledSamples)(int ch_index, __int64 position, int count, double* data, double* time_stamp);
typedef int (*_DWGetEventListCount)(void);
typedef enum DWStatus (*_DWGetEventList)(struct DWEvent* event_list);
typedef enum DWStatus (*_DWExportHeader)(char* file_name);
typedef int (*_DWGetTextChannelListCount)(void);
typedef enum DWStatus (*_DWGetTextChannelList)(struct DWChannel* channel_list);
typedef __int64 (*_DWGetTextValuesCount)(int ch_index);
typedef enum DWStatus (*_DWGetTextValues)(int ch_index, int position, int count, char* text_values, double* time_stamp);
typedef enum DWStatus (*_DWGetReducedValuesCount)(int ch_index, int* count, double* block_size);
typedef enum DWStatus (*_DWGetReducedValues)(int ch_index, int position, int count, struct DWReducedValue* data);
typedef int (*_DWGetHeaderEntryCount)(void);
typedef enum DWStatus (*_DWGetHeaderEntryList)(struct DWChannel* channel_list);
typedef enum DWStatus (*_DWGetHeaderEntryText)(int ch_index, char* text_value, int text_value_size);
typedef int (*_DWGetStoringType)(void);
typedef int (*_DWGetArrayInfoCount)(int ch_index);
typedef enum DWStatus (*_DWGetArrayInfoList)(int ch_index, struct DWArrayInfo* array_inf_list);
typedef enum DWStatus (*_DWGetArrayIndexValue)(int ch_index, int array_info_index, int array_value_index, char* value, int value_size);

void* hInstLibrary;
int m_InitDLL;

//functions
_DWInit DWInit;
_DWDeInit DWDeInit;
_DWGetVersion DWGetVersion;
_DWOpenDataFile DWOpenDataFile;
_DWCloseDataFile DWCloseDataFile;
_DWGetChannelListCount DWGetChannelListCount;
_DWGetChannelList DWGetChannelList;
_DWGetChannelFactors DWGetChannelFactors;
_DWGetScaledSamplesCount DWGetScaledSamplesCount;
_DWGetScaledSamples DWGetScaledSamples;
_DWGetEventListCount DWGetEventListCount;
_DWGetEventList DWGetEventList;
_DWExportHeader DWExportHeader;
_DWGetTextChannelListCount DWGetTextChannelListCount;
_DWGetTextChannelList DWGetTextChannelList;
_DWGetTextValuesCount DWGetTextValuesCount;
_DWGetTextValues DWGetTextValues;
_DWGetReducedValuesCount DWGetReducedValuesCount;
_DWGetReducedValues DWGetReducedValues;
_DWGetHeaderEntryCount DWGetHeaderEntryCount;
_DWGetHeaderEntryList DWGetHeaderEntryList;
_DWGetHeaderEntryText DWGetHeaderEntryText;
_DWGetStoringType DWGetStoringType;
_DWGetArrayInfoCount DWGetArrayInfoCount;
_DWGetArrayInfoList DWGetArrayInfoList;
_DWGetArrayIndexValue DWGetArrayIndexValue;

int LoadDWDLL();
int CloseDWDLL();

#endif
