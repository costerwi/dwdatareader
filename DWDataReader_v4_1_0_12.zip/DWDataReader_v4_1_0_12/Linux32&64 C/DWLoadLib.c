#include "DWLoadLib.h"

int LoadDWDLL()
{
	hInstLibrary = dlopen("/home/dewesoft/Desktop/DWDataReader/DLib/Debug/DWDataReaderLib.so", RTLD_LAZY);
	if (!hInstLibrary)
		return 0;
	DWInit = (_DWInit)dlsym(hInstLibrary, "DWInit");
	if (!DWInit)
		return 0;
	DWDeInit = (_DWDeInit)dlsym(hInstLibrary, "DWDeInit");
	if (!DWDeInit)
		return 0;
	DWGetVersion = (_DWGetVersion)dlsym(hInstLibrary, "DWGetVersion");
	if (!DWGetVersion)
		return 0;
	DWOpenDataFile = (_DWOpenDataFile)dlsym(hInstLibrary, "DWOpenDataFile");
	if (!DWOpenDataFile)
		return 0;
	DWCloseDataFile = (_DWCloseDataFile)dlsym(hInstLibrary, "DWCloseDataFile");
	if (!DWCloseDataFile)
		return 0;
	DWGetChannelListCount = (_DWGetChannelListCount)dlsym(hInstLibrary, "DWGetChannelListCount");
	if (!DWGetChannelListCount)
		return 0;
	DWGetChannelList = (_DWGetChannelList)dlsym(hInstLibrary, "DWGetChannelList");
	if (!DWGetChannelList)
		return 0;
	DWGetChannelFactors = (_DWGetChannelFactors)dlsym(hInstLibrary, "DWGetChannelFactors");
	if (!DWGetChannelFactors)
		return 0;
	DWGetScaledSamplesCount = (_DWGetScaledSamplesCount)dlsym(hInstLibrary, "DWGetScaledSamplesCount");
	if (!DWGetScaledSamplesCount)
		return 0;
	DWGetScaledSamples = (_DWGetScaledSamples)dlsym(hInstLibrary, "DWGetScaledSamples");
	if (!DWGetScaledSamples)
		return 0;
	DWGetEventListCount = (_DWGetEventListCount)dlsym(hInstLibrary, "DWGetEventListCount");
	if (!DWGetEventListCount)
		return 0;
	DWGetEventList = (_DWGetEventList)dlsym(hInstLibrary, "DWGetEventList");
	if (!DWGetEventList)
		return 0;
	DWExportHeader = (_DWExportHeader)dlsym(hInstLibrary, "DWExportHeader");
	if (!DWExportHeader)
		return 0;
	DWGetTextChannelListCount = (_DWGetTextChannelListCount)dlsym(hInstLibrary, "DWGetTextChannelListCount");
	if (!DWGetTextChannelListCount)
		return 0;
	DWGetTextChannelList = (_DWGetTextChannelList)dlsym(hInstLibrary, "DWGetTextChannelList");
	if (!DWGetTextChannelList)
		return 0;
	DWGetTextValuesCount = (_DWGetTextValuesCount)dlsym(hInstLibrary, "DWGetTextValuesCount");
	if (!DWGetTextValuesCount)
		return 0;
	DWGetTextValues = (_DWGetTextValues)dlsym(hInstLibrary, "DWGetTextValues");
	if (!DWGetTextValues)
		return 0;
	DWGetReducedValuesCount = (_DWGetReducedValuesCount)dlsym(hInstLibrary, "DWGetReducedValuesCount");
	if (!DWGetReducedValuesCount)
		return 0;
	DWGetReducedValues = (_DWGetReducedValues)dlsym(hInstLibrary, "DWGetReducedValues");
	if (!DWGetReducedValues)
		return 0;
	DWGetHeaderEntryCount = (_DWGetHeaderEntryCount)dlsym(hInstLibrary, "DWGetHeaderEntryCount");
	if (!DWGetHeaderEntryCount)
		return 0;
	DWGetHeaderEntryList = (_DWGetHeaderEntryList)dlsym(hInstLibrary, "DWGetHeaderEntryList");
	if (!DWGetHeaderEntryList)
		return 0;
	DWGetHeaderEntryText = (_DWGetHeaderEntryText)dlsym(hInstLibrary, "DWGetHeaderEntryText");
	if (!DWGetHeaderEntryText)
		return 0;
	DWGetStoringType = (_DWGetStoringType)dlsym(hInstLibrary, "DWGetStoringType");
	if (!DWGetStoringType)
		return 0;
	DWGetArrayInfoCount = (_DWGetArrayInfoCount)dlsym(hInstLibrary, "DWGetArrayInfoCount");
	if (!DWGetArrayInfoCount)
		return 0;
	DWGetArrayInfoList = (_DWGetArrayInfoList)dlsym(hInstLibrary, "DWGetArrayInfoList");
	if (!DWGetArrayInfoList)
		return 0;
	DWGetArrayIndexValue = (_DWGetArrayIndexValue)dlsym(hInstLibrary, "DWGetArrayIndexValue");
	if (!DWGetArrayIndexValue)
		return 0;

	return 1;
}

int CloseDWDLL()
{
	return dlclose(hInstLibrary);
}

