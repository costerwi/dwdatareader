#include <windows.h>

#ifndef DWLOADLIB__H
#define DWLOADLIB__H

enum DWStatus					// status returned from library function calls
{
	DWSTAT_OK = 0,									// status OK
	DWSTAT_ERROR = 1, 								// error occurred in the dll
	DWSTAT_ERROR_FILE_CANNOT_OPEN = 2,				// unable to open file
	DWSTAT_ERROR_FILE_ALREADY_IN_USE = 3,			// file already in use
	DWSTAT_ERROR_FILE_CORRUPT = 4, 					// file corrupted
	DWSTAT_ERROR_NO_MEMORY_ALLOC = 5,				// memory not allocated
	DWSTAT_ERROR_CREATE_DEST_FILE = 6,				// error creating destination file (only for d7z files)
	DWSTAT_ERROR_EXTRACTING_FILE = 7,				// error extracting data (only for d7z files)
	DWSTAT_ERROR_CANNOT_OPEN_EXTRACTED_FILE = 8		// error opening extracted file (only for d7z files)
};

// channel properties
enum DWChannelProps				// used for DWGetChannelProps() calls
{
	DW_DATA_TYPE = 0,	     	// get data type
	DW_DATA_TYPE_LEN_BYTES = 1,	// get length of data type in bytes
	DW_CH_INDEX = 2,			// get channel index
	DW_CH_INDEX_LEN = 3,		// get length of channel index
	DW_CH_TYPE = 4,				// get channel type
	DW_CH_SCALE = 5,			// get channel scale
	DW_CH_OFFSET = 6,			// get channel offset
	DW_CH_XML = 7,				// get channel XML
	DW_CH_XML_LEN = 8,			// get length of channel XML
	DW_CH_XMLPROPS = 9,			// get channel XML properties
	DW_CH_XMLPROPS_LEN = 10		// get length of channel XML properties

};

enum DWChannelType				// channel type
{
	DW_CH_TYPE_SYNC = 0,		// sync channel
	DW_CH_TYPE_ASYNC = 1,		// async channel
	DW_CH_TYPE_SV = 2			// single value channel
};

#pragma pack(push)
#pragma pack(1)
struct DWFileInfo				// structure used for data file
{ 
	double sample_rate;			// the sampling rate
	double start_store_time;	// absolute time of the start of storing (days)
	double duration;			// duration of data file (seconds)
};

#pragma pack(1)
struct DWChannel				// structure used for DeweSoft channel
{
	int index;					// unique channel identifier  
	char name[100];				// the name of a channel
	char unit[20];				// the unit of a channel
	char description[200];		// the description of a channel
	unsigned int color;			// specifies the color of a channel
	int array_size;				// length of the array channel (normal array_size = 1)
};

#pragma pack(1)
struct DWEvent
{
	int event_type;				// 1..start event; 2..stop event
	double time_stamp;			// relative position in seconds
	char event_text[200];
};

#pragma pack(1)
struct DWReducedValue
{
    double time_stamp;			// relative time in seconds
    double ave;
    double min;
	double max;
	double rms;
};

#pragma pack(1)
struct DWArrayInfo
{
	int index;				// unique axis identifier  
	char name[100];			// axis name
	char unit[20];			// axis unit
	int size;				// length of the axis size
};

#pragma pack(1)
struct DWComplex
{
	double re;
	double im;
};
#pragma pack(pop)

//event list
#define etStart 1
#define etStop 2
#define etTrigger 3
#define etVStart 11
#define etVStop 12
#define etKeyboard 20
#define etNotice 21
#define etVoice 22
#define etModule 24

//Storing type
#define ST_ALWAYS_FAST 0
#define ST_ALWAYS_SLOW 1
#define ST_FAST_ON_TRIGGER 2
#define ST_FAST_ON_TRIGGER_SLOW_OTH 3 

// data types in buffer
#define MaxDataTypes 12
#define dtByte 0
#define dtShortInt 1
#define dtSmallInt 2
#define dtWord 3
#define dtInteger 4
#define dtSingle 5
#define dtInt64 6
#define dtDouble 7
#define dtLongword 8
#define dtComplexSingle 9
#define dtComplexDouble 10
#define dtText 11

//FUNCTIONS:
typedef enum DWStatus (*_DWInit)(void);
typedef enum DWStatus (*_DWDeInit)(void);
typedef enum DWStatus (*_DWAddReader)(void);
typedef enum DWStatus (*_DWGetNumReaders)(int* num_readers);
typedef enum DWStatus (*_DWSetActiveReader)(int index);
typedef int (*_DWGetVersion)(void);
typedef enum DWStatus (*_DWOpenDataFile)(char* file_name, struct DWFileInfo* file_info);
typedef enum DWStatus (*_DWCloseDataFile)(void);
typedef int (*_DWGetChannelListCount)(void);
typedef enum DWStatus (*_DWGetChannelList)(struct DWChannel* channel_list);
typedef enum DWStatus (*_DWGetChannelFactors)(int ch_index, double* scale, double* offset);
typedef enum DWStatus (*_DWGetChannelProps)(int ch_index, enum DWChannelProps ch_prop, void* buffer, int* max_len);
typedef __int64 (*_DWGetScaledSamplesCount)(int ch_index);
typedef  enum DWStatus (*_DWGetScaledSamples)(int ch_index, __int64 position, int count, double* data, double* time_stamp);
typedef __int64 (*_DWGetRawSamplesCount)(int ch_index);
typedef  enum DWStatus (*_DWGetRawSamples)(int ch_index, __int64 position, int count, void* data, double* time_stamp);
typedef int (*_DWGetComplexChannelListCount)(void);
typedef enum DWStatus (*_DWGetComplexChannelList)(struct DWChannel* channel_list);
typedef __int64 (*_DWGetComplexScaledSamplesCount)(int ch_index);
typedef  enum DWStatus (*_DWGetComplexScaledSamples)(int ch_index, __int64 position, int count, struct DWComplex* data, double* time_stamp);
typedef __int64 (*_DWGetComplexRawSamplesCount)(int ch_index);
typedef  enum DWStatus (*_DWGetComplexRawSamples)(int ch_index, __int64 position, int count, struct DWComplex* data, double* time_stamp);
typedef int (*_DWGetEventListCount)(void);
typedef enum DWStatus (*_DWGetEventList)(struct DWEvent* event_list);
typedef enum DWStatus (*_DWGetStream)(char* stream_name, char* buffer, int* max_len);
typedef enum DWStatus (*_DWExportHeader)(char* file_name);
typedef int (*_DWGetTextChannelListCount)(void);
typedef enum DWStatus (*_DWGetTextChannelList)(struct DWChannel* channel_list);
typedef __int64 (*_DWGetTextValuesCount)(int ch_index);
typedef enum DWStatus (*_DWGetTextValues)(int ch_index, int position, int count, char* text_values, double* time_stamp);
typedef enum DWStatus (*_DWGetReducedValuesCount)(int ch_index, int* count, double* block_size);
typedef enum DWStatus (*_DWGetReducedValues)(int ch_index, int position, int count, struct DWReducedValue* data);
typedef int (*_DWGetHeaderEntryCount)(void);
typedef enum DWStatus (*_DWGetHeaderEntryList)(struct DWChannel* channel_list);
typedef enum DWStatus (*_DWGetHeaderEntryText)(int ch_index, char* text_value, int text_value_size);
typedef int (*_DWGetStoringType)(void);
typedef int (*_DWGetArrayInfoCount)(int ch_index);
typedef enum DWStatus (*_DWGetArrayInfoList)(int ch_index, struct DWArrayInfo* array_inf_list);
typedef enum DWStatus (*_DWGetArrayIndexValue)(int ch_index, int array_info_index, int array_value_index, char* value, int value_size);
typedef enum DWStatus (*_DWGetArrayIndexValueF)(int ch_index, int array_info_index, int array_value_index, double* value);

//spec. m
typedef enum DWStatus (*_DWGetChannelListItem)(int array_index, int* index, char* name, char* unit, char* description, int* color, int* array_size, int max_char_size);
typedef enum DWStatus (*_DWGetHeaderEntryListItem)(int array_index, int* index, char* name, char* unit, char* description, int* color, int* array_size, int max_char_size);
typedef enum DWStatus (*_DWGetEventListItem)(int event_Index, int* event_type, double* time_stamp, char* event_text, int max_char_size);
typedef enum DWStatus (*_DWGetReducedAveValues)(int ch_index, int position, int count, double* data, double* time_stamp);
typedef enum DWStatus (*_DWGetReducedMinValues)(int ch_index, int position, int count, double* data, double* time_stamp);
typedef enum DWStatus (*_DWGetReducedMaxValues)(int ch_index, int position, int count, double* data, double* time_stamp);
typedef enum DWStatus (*_DWGetReducedRMSValues)(int ch_index, int position, int count, double* data, double* time_stamp);

//spec. f
typedef enum DWStatus (*_DWGetHeaderEntryTextF)(int entry_number, char* text_value, int text_value_size);
typedef enum DWStatus (*_DWGetHeaderEntryNameF)(int entry_number, char* name, int name_size);
typedef enum DWStatus (*_DWGetHeaderEntryIDF)(int entry_number, char* ID, int name_size);
typedef double (*_DWGetEventTimeF)(int event_number);
typedef enum DWStatus (*_DWGetEventTextF)(int event_number, char* text, int text_size);
typedef int (*_DWGetEventTypeF)(int event_number);
typedef int (*_DWGetReducedDataChannelCountF)(void);
typedef enum DWStatus (*_DWGetReducedDataChannelNameF)(int Channel_Number, char* name, int name_size);
typedef int (*_DWGetReducedDataChannelIndexF)(char* name);
typedef enum DWStatus (*_DWGetRecudedDataChannelInfoF)(int Channel_Number, char* X_Axis_Units, int X_Axis_Units_size, char* Y_Axis_Units, int Y_Axis_Units_size, double* Chn_Offset, int* Channel_Length, double* ch_rate);
typedef enum DWStatus (*_DWGetRecudedDataF)(int Channel_Number, double* X_Axis, double* Y_Axis, int position, int count);
typedef enum DWStatus (*_DWGetRecudedYDataF)(int Channel_Number, double* Y_Axis, int position, int count);
typedef enum DWStatus (*_DWGetRecudedDataAllF)(int Channel_Number, double* Y_MIN_Axis, double* Y_AVE_Axis, double* Y_MAX_Axis, double* Y_RMS_Axis, int position, int count);
typedef int (*_DWGetTriggerDataTriggerCountF)(void);
typedef double (*_DWGetTriggerDataTriggerTimeF)(int Trigger_Number);
typedef enum DWStatus (*_DWGetTriggerDataChannelNameF)(int Channel_Number, char* name, int name_size);
typedef int (*_DWGetTriggerDataChannelIndexF)(char* name);
typedef enum DWStatus (*_DWGetTriggerDataChannelInfoF)(int Trigger_Number, int Channel_Number, char* X_Axis_Units, int X_Axis_Units_size, char* Y_Axis_Units, int Y_Axis_Units_size, double* Chn_Offset, double* Channel_Length, double* ch_rate, int* ch_type);
typedef enum DWStatus (*_DWGetTriggerDataF)(int Trigger_Number , int Channel_Number, double* Y_Axis, double* X_Axis, double position, int count);

HINSTANCE hInstLibrary;//Dll handle
int m_InitDLL;

//functions
_DWInit DWInit;
_DWDeInit DWDeInit;
_DWAddReader DWAddReader;
_DWGetNumReaders DWGetNumReaders;
_DWSetActiveReader DWSetActiveReader;
_DWGetVersion DWGetVersion;
_DWOpenDataFile DWOpenDataFile;
_DWCloseDataFile DWCloseDataFile;
_DWGetChannelListCount DWGetChannelListCount;
_DWGetChannelList DWGetChannelList;
_DWGetChannelFactors DWGetChannelFactors;
_DWGetChannelProps DWGetChannelProps;
_DWGetScaledSamplesCount DWGetScaledSamplesCount;
_DWGetScaledSamples DWGetScaledSamples;
_DWGetRawSamplesCount DWGetRawSamplesCount;
_DWGetRawSamples DWGetRawSamples;
_DWGetComplexChannelListCount DWGetComplexChannelListCount;
_DWGetComplexChannelList DWGetComplexChannelList;
_DWGetComplexScaledSamplesCount DWGetComplexScaledSamplesCount;
_DWGetComplexScaledSamples DWGetComplexScaledSamples;
_DWGetComplexRawSamplesCount DWGetComplexRawSamplesCount;
_DWGetComplexRawSamples DWGetComplexRawSamples;
_DWGetEventListCount DWGetEventListCount;
_DWGetEventList DWGetEventList;
_DWGetStream DWGetStream;
_DWExportHeader DWExportHeader;
_DWGetTextChannelListCount DWGetTextChannelListCount;
_DWGetTextChannelList DWGetTextChannelList;
_DWGetTextValuesCount DWGetTextValuesCount;
_DWGetTextValues DWGetTextValues;
_DWGetReducedValuesCount DWGetReducedValuesCount;
_DWGetReducedValues DWGetReducedValues;
_DWGetHeaderEntryCount DWGetHeaderEntryCount;
_DWGetHeaderEntryList DWGetHeaderEntryList;
_DWGetHeaderEntryText DWGetHeaderEntryText;
_DWGetStoringType DWGetStoringType;
_DWGetArrayInfoCount DWGetArrayInfoCount;
_DWGetArrayInfoList DWGetArrayInfoList;
_DWGetArrayIndexValue DWGetArrayIndexValue;
_DWGetArrayIndexValueF DWGetArrayIndexValueF;
//
_DWGetChannelListItem DWGetChannelListItem;
_DWGetHeaderEntryListItem DWGetHeaderEntryListItem;
_DWGetEventListItem DWGetEventListItem;
_DWGetReducedAveValues DWGetReducedAveValues;
_DWGetReducedMinValues DWGetReducedMinValues;
_DWGetReducedMaxValues DWGetReducedMaxValues;
_DWGetReducedRMSValues DWGetReducedRMSValues;
//
_DWGetHeaderEntryTextF DWGetHeaderEntryTextF;
_DWGetHeaderEntryNameF DWGetHeaderEntryNameF;
_DWGetHeaderEntryIDF DWGetHeaderEntryIDF;
_DWGetEventTimeF DWGetEventTimeF;
_DWGetEventTextF DWGetEventTextF;
_DWGetEventTypeF DWGetEventTypeF;
_DWGetReducedDataChannelCountF DWGetReducedDataChannelCountF;
_DWGetReducedDataChannelNameF DWGetReducedDataChannelNameF;
_DWGetReducedDataChannelIndexF DWGetReducedDataChannelIndexF;
_DWGetRecudedDataChannelInfoF DWGetRecudedDataChannelInfoF;
_DWGetRecudedDataF DWGetRecudedDataF;
_DWGetRecudedYDataF DWGetRecudedYDataF;
_DWGetRecudedDataAllF DWGetRecudedDataAllF;
_DWGetTriggerDataTriggerCountF DWGetTriggerDataTriggerCountF;
_DWGetTriggerDataTriggerTimeF DWGetTriggerDataTriggerTimeF;
_DWGetTriggerDataChannelNameF DWGetTriggerDataChannelNameF;
_DWGetTriggerDataChannelIndexF DWGetTriggerDataChannelIndexF;
_DWGetTriggerDataChannelInfoF DWGetTriggerDataChannelInfoF;
_DWGetTriggerDataF DWGetTriggerDataF;

int LoadDWDLL(const char* lib_name);
int CloseDWDLL();

#endif
