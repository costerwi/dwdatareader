% Matlab Dewesoft import - version 1.3
%
% v1.0
% supports basic parameters transfer (sample rate,...)
% supports direct buffer data (synch and asynch)
% channel names, colors, timestamps
%
% v1.1
% added event list support
%
% v1.2
% 64 bit support 
%
% v1.3 
% added reading of IB buffers (min, max, rms, ave)
%
% v1.4
% index for channels for reading reduced data was wrong in version 1.3
%
% v1.5 added reading of header data from file

% clear old variables
clear;

% if 64-bit then load 64-bit dll 
if (strcmp(computer, 'PCWIN64') == 1) 
    DWDataLibFile = 'DWDataReaderLib64'; 
else
    DWDataLibFile = 'DWDataReaderLib'; 
end;   

% load dll with heade file
loadlibrary([DWDataLibFile, '.dll'], 'DWDataReaderLib.h');
% list all dll functions
libfunctions(DWDataLibFile);

% initiate data reader
calllib(DWDataLibFile, 'DWInit');

% get version of dll
ver = calllib(DWDataLibFile, 'DWGetVersion');
disp(sprintf('Dll version: %d', ver));

% create ctructures to pass to dll functions 
str = libstruct('DWFileInfo');
sptr = libpointer('DWFileInfo', str);

% open file
[stat, file_name, info_data] = calllib(DWDataLibFile, 'DWOpenDataFile', 'c:\Test.d7d', sptr.Value);
disp(sprintf('Sample rate: %d', info_data.sample_rate));
disp(sprintf('Start store time: %d', info_data.start_store_time));
disp(sprintf('File duration: %d', info_data.duration));

% read number of channels in Dewesoft
[channel_count] = calllib(DWDataLibFile, 'DWGetChannelListCount');
disp(sprintf('Number of channels: %d', channel_count));

% y axis has channel names label
ylabel_str = '';
% maximum time for data
max_out_time = 0;

% go through all events in file
[event_count] = calllib(DWDataLibFile, 'DWGetEventListCount');
for i = 0:event_count - 1 
    in_index = i;
    in_max_count = 100;
    in_event_type = 0;
    in_timestamp = 0;
    in_event_text = blanks(in_max_count);
    [info, out_event_type, out_timestamp, out_event_text] = calllib(DWDataLibFile, 'DWGetEventListItem', in_index, in_event_type, in_timestamp, in_event_text, in_max_count);
    % print event out
    ['Event number: ', int2str(out_event_type), '; Timestamp: ', num2str(out_timestamp), '; Event text: ', out_event_text]
end;    
    
% go through all the channels and find color, name... and index
for i = 0:channel_count - 1 
    in_array_index = i;
    in_index = 0;
    in_color = 0;
    in_max_count = 100;
    in_name = blanks(in_max_count);   % blanks reservers memory for reading data back to Matlab
    in_unit = blanks(in_max_count);
    in_description = blanks(in_max_count); 
    in_array_size = 0;
    [info, out_index, out_name, out_unit, out_description, out_color, out_array_size] = calllib(DWDataLibFile, 'DWGetChannelListItem', in_array_index, in_index, in_name, in_unit, in_description, in_color, in_array_size, in_max_count);
   
    % build y string for channel names
    ylabel_str = strcat(ylabel_str, ', ', out_name);
       
    % get number of samples for channel
    sample_cnt = 0;
    [sample_cnt] = calllib(DWDataLibFile, 'DWGetScaledSamplesCount', out_index);
    
    % draw graph only once
    if i == 0  
        figure;
    end;
    
    % if there is some samples in the data file then read sample values and
    % corresponding time stamps (also synchronous channels have timestamps)
    if sample_cnt > 0 
        data = repmat(0.0, sample_cnt, 1);
        time_stamp = repmat(0.0, sample_cnt, 1);
        [info, out_data, out_time_stamp] = calllib(DWDataLibFile, 'DWGetScaledSamples', out_index, 0, sample_cnt, data, time_stamp); 
                
        % maximum for x axis
        max_out_time = max(max_out_time, out_time_stamp(length(out_time_stamp))); 

        % plot data on one graph color read out from file
        colr = [bitand(uint32(out_color), 16711680) / 16711680, bitand(uint32(out_color), 65280) / 65280, bitand(uint32(out_color), 255) / 255];
        plot(out_time_stamp, out_data, 'Color', colr)
        
        hold on;
    end;
    
    % read values from reduced buffer 
    in_sample_count_r = 0;
    in_block_size_r = 0;
    [info, out_sample_count_r, out_block_size_r] = calllib(DWDataLibFile, 'DWGetReducedValuesCount', out_index, in_sample_count_r, in_block_size_r);

    if out_sample_count_r > 0
        in_position_r = 0;
        in_count_r = out_sample_count_r;
        in_timestamp_r = repmat(0.0, out_sample_count_r, 1);
        in_data_r = repmat(0.0, out_sample_count_r, 1);
        [info, out_ave_data_r, out_timestamp_r] = calllib(DWDataLibFile, 'DWGetReducedAveValues', out_index, in_position_r, in_count_r, in_data_r, in_timestamp_r);
        [info, out_min_data_r, out_timestamp_r] = calllib(DWDataLibFile, 'DWGetReducedMinValues', out_index, in_position_r, in_count_r, in_data_r, in_timestamp_r);
        [info, out_max_data_r, out_timestamp_r] = calllib(DWDataLibFile, 'DWGetReducedMaxValues', out_index, in_position_r, in_count_r, in_data_r, in_timestamp_r);
        [info, out_rms_data_r, out_timestamp_r] = calllib(DWDataLibFile, 'DWGetReducedRMSValues', out_index, in_position_r, in_count_r, in_data_r, in_timestamp_r);
    end;
end;

% read header information from file
in_header_count = 255;
[out_header_count] = calllib(DWDataLibFile, 'DWGetHeaderEntryCount')

for i = 0:out_header_count - 1 
    in_array_index = i;
    in_index = 0;
    in_color = 0;
    in_max_count = 100;
    in_name = blanks(in_max_count);   % blanks reservers memory for reading data back to Matlab
    in_unit = blanks(in_max_count);
    in_description = blanks(in_max_count); 
    in_array_size = 0;
    [info, out_index, out_name, out_unit, out_description, out_color, out_array_size] = calllib(DWDataLibFile, 'DWGetHeaderEntryListItem', in_array_index, in_index, in_name, in_unit, in_description, in_color, in_array_size, in_max_count);
    
    in_header_text = blanks(in_header_count);
    [stat, header_info] = calllib(DWDataLibFile, 'DWGetHeaderEntryText', out_index, in_header_text, in_header_count);
    
    disp(sprintf('Header entry name: %s - Header entry value: %s', out_name, header_info));
end;

title(sprintf('Number of channels: %d', channel_count));
% set channel names on y label
ylabel(strcat('Dewesoft channels: ', ylabel_str));
% set corret min and max on x and y axis
if max_out_time > 0
    axis([0, max_out_time, -5, 5]); 
end;

% close file and deinit reader
calllib(DWDataLibFile, 'DWCloseDataFile');
calllib(DWDataLibFile, 'DWDeInit');

% libstruct variables need to be cleared befor unloading library, because
% of bug in Matlab 7.0
clear sptr;
clear str;
% unload DLL from memory
unloadlibrary(DWDataLibFile);
